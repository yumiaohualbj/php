<!DOCTYPE html>
<!--
To change this license header, choose License Headers in Project Properties.
To change this template file, choose Tools | Templates
and open the template in the editor.
-->
<html>
    <head>
        <meta charset="UTF-8">
        <title></title>
    </head>
    <body>
        <h1>数据库</h1>
               <?php
        $con = new mysqli("localhost", "root", "root", "my_db");
        $sql = "select * from Persons";
        $result = $con->query($sql);
        $row = $result->assoc();
        echo $row["name"];
        $result->free();
        $mysqli->close();
        echo "yumiaohua";

// some code

        // put your code here
        ?>
    </body>
</html>
